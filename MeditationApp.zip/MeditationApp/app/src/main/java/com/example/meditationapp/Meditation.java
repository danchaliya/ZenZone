package com.example.meditationapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
//import freetts;

public class Meditation extends AppCompatActivity {

    TextView Title;
    private static String PARAM_TIME;
    private static String PARAM_THEME;
    private static String PARAM_LEVEL;
    private static String[] PARAMETERS = new String[3];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meditation);

        Title = (TextView) findViewById(R.id.textViewMeditName);
    }

    
    public void voice ()
    {
        PARAM_TIME = "5 minutes";
        PARAM_THEME = "ocean";
        PARAM_LEVEL = "easy";
        PARAMETERS[0] = PARAM_TIME;
        PARAMETERS[1] = PARAM_THEME;
        PARAMETERS[2] = PARAM_LEVEL;
        //controller.play_meditation(PARAMETERS);
    }
}